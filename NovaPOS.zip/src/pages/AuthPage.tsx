import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthContext } from '../contexts/AuthContext'

export const AuthPage = () => {
  const navigate = useNavigate()
  const { googleSession } = useAuthContext()

  useEffect(() => {
    if (googleSession) {
      navigate('/login', { replace: true })
    } else {
      navigate('/auth-google', { replace: true })
    }
  }, [googleSession, navigate])

  return null
}
