import { StrictMode, useEffect, useRef } from 'react'
import { createRoot } from 'react-dom/client'
import { GoogleOAuthProvider } from '@react-oauth/google'
import './index.css'
import App from './App.tsx'
import { AuthProvider } from './contexts/AuthContext'
import { useAuthContext } from './contexts/AuthContext'

const AppBootstrap = () => {
  const { initializeApp } = useAuthContext()
  const bootstrapped = useRef(false)

  useEffect(() => {
    if (bootstrapped.current) return
    bootstrapped.current = true
    void initializeApp()
  }, [initializeApp])

  return <App />
}

const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <GoogleOAuthProvider clientId={clientId}>
      <AuthProvider>
        <AppBootstrap />
      </AuthProvider>
    </GoogleOAuthProvider>
  </StrictMode>,
)
